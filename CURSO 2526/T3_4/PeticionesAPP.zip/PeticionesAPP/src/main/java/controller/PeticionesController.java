package controller;

import dao.UsuarioDAOImp;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import model.Usuario;
import model.UsuarioLista;
import model.UsuarioXML;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PeticionesController {

    // la capa de logica pero no contra base de datos
    // si un usuario se registra -> como actuar ante un error producido por elementos
    // externos
    // mandar un correo electronico a todos los elementos
    // extraer todos los datos de la base de datos
    private UsuarioDAOImp usuarioDAOImp;

    public PeticionesController() {
        usuarioDAOImp = new UsuarioDAOImp();
    }

    public void insertarUsuario(Usuario usuario) {
        // voy intentar insertar un usuario
        // si tengo un error en el correo
        // pido nuevamente el correo y lo intento agregar nuevamente
        Scanner scanner = new Scanner(System.in);
        boolean fallo = false;
        String correo;

        do {
            try {
                usuarioDAOImp.insertarDato(usuario);
                fallo = false;
            } catch (SQLException e) {
                System.out.println("Error, correo duplicado");
                System.out.println("Por favor introduce un nuevo correo");
                fallo = true;
                correo = scanner.next();
                usuario.setMail(correo);
            }
        } while (fallo);
        System.out.println("Usuario agregado correctamente");
    }

    public void borrarUsuario(int id) {
        // la logica
        // quiere borrar tambien todos los documentos asociados usuario con id
        int rows = usuarioDAOImp.borrarDatos(id);
        if (rows > 1) {
            System.out.println("Usuarios borrados correctamente");
        } else if (rows == 1) {
            System.out.println("usuario borrado correctamente");
        } else if (rows == 0) {
            System.out.println("No se ha encontrado usuario con ese id");
        } else {
            System.out.println("Fallo en el proceso");
            // dime el id del que quieres borrar
        }
    }

    public void actualiarDatos(String nombre) {
        // DAO -> busqueda por nombre
        // pidiendo de uno en uno el nuevo correo
        // DAO de uno en uno -> actualizar por nombre
    }

    public void exporta() {

        List<UsuarioXML> usuarios = usuarioDAOImp.obtenerListaDato();
        UsuarioLista usuarioLista = new UsuarioLista();
        usuarioLista.setLista(usuarios);

        JAXBContext context = null;
        try {
            context = JAXBContext.newInstance(UsuarioLista.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.marshal(usuarioLista, new File("src/main/java/controller/usuarios_exportado.xml"));
        } catch (JAXBException e) {
            throw new RuntimeException(e);
        }

    }

    public void importa() {

        JAXBContext context;

        {
            try {
                context = JAXBContext.newInstance(UsuarioLista.class);
                Unmarshaller unmarshaller = context.createUnmarshaller();
                UsuarioLista personas = (UsuarioLista) unmarshaller.unmarshal(new File("src/main/java/controller/usuarios.xml"));
                for (UsuarioXML item : personas.getLista() ) {
                    usuarioDAOImp.insertarD(item);
                }
            } catch (JAXBException e) {
                throw new RuntimeException(e);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }

    }


    public void listarUsuarios() {
        // System.out.println("Quieres listar todos los datos o solo alguno");
        for (Usuario item : usuarioDAOImp.obtenerListaDatos()) {
            item.mostrarDatos();
        }
    }

}
