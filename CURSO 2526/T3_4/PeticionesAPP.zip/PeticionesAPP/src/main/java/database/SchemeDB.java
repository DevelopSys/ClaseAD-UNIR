package database;

public interface SchemeDB {
    // metodos -> NO ESCRITOS
    // atributos -> PUBLICOS FINAL STATIL
    String DB_NAME = "peticiones";
    String TAB_NAME = "usuarios";
    String COL_NAME = "nombre";
    String COL_MAIL = "mail";
    String COL_PHONE = "telefono";
    String COL_PROFILE = "id_perfil";
    String COL_ID = "id";
}
